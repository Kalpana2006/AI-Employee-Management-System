from flask import Flask, render_template, request
import joblib
import numpy as np

app = Flask(__name__)

model = joblib.load('employee_model.pkl')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    attendance = int(request.form['attendance'])
    experience = int(request.form['experience'])
    projects = int(request.form['projects'])
    rating = int(request.form['rating'])
    overtime = int(request.form['overtime'])

    data = np.array([[attendance, experience, projects, rating, overtime]])

    prediction = model.predict(data)[0]

    return render_template('result.html', prediction=prediction)

@app.route('/add')
def add_employee():
    return render_template('add_employee.html')

if __name__ == '__main__':
    app.run(debug=True)
