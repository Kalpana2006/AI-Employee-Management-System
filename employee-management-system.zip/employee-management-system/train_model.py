import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import joblib

df = pd.read_csv('employees.csv')

X = df[['Attendance', 'Experience', 'Projects', 'Rating', 'Overtime']]
y = df['Performance']

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

model = RandomForestClassifier()

model.fit(X_train, y_train)

predictions = model.predict(X_test)

accuracy = accuracy_score(y_test, predictions)
print('Model Accuracy:', accuracy)

joblib.dump(model, 'employee_model.pkl')

print('Model trained and saved successfully!')
